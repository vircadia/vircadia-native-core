'use strict';
/* jshint ignore:start */
var doc1 = {
    "_id": "1",
    "name": "javascript",
    "type": "dynamic",
    "category": "PL",
    "desc": "The most popular!"
};

var doc2 = {
    "_id": "2",
    "name": "scala-js",
    "type": "static",
    "category": "PL",
    "desc": "The new cool kid!"
};

var doc3 = {
    "_id": "3",
    "name": "clojure",
    "type": "dynamic",
    "category": "PL",
    "desc": "Rich Hickey Master piece!"
};

module.exports = [doc1, doc2, doc3];
/* jshint ignore:end */