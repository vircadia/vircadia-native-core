'use strict';
var doc1 = {
  "_id": "1",
  "title": "III",
  "text": "some text"
};
var doc2 = {
  "_id": "2",
  "title": "III",
  "text": "some text"
};

module.exports = [doc1, doc2];