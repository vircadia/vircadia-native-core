The following script files are provided under the Apache License. Read each license for more details.

pouchDB 			https://pouchdb.com/download.html
replication-stream-master	https://github.com/pouchdb-community/pouchdb-replication-stream
quick-search-master		https://github.com/pouchdb-community/pouchdb-quick-search

Packo is covered under an MIT license.

Packo 				https://github.com/nodeca/pako